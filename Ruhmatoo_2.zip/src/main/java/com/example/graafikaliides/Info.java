package com.example.graafikaliides;

import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

public class Info {
    private VBox juur;

    public VBox getJuur() {
        return juur;
    }

    public Info(Stage primaryStage, Mängija mängija) {
        juur = new VBox();
        primaryStage.setTitle("Info");
        juur.setAlignment(Pos.CENTER);

        Label info_tekstina = new Label(
                """
                        Mängud programmeerimiskeeles Java.
                        See on meie rühmatöö aines Objektorienteeritud programmeerimine (OOP).
                        Mängimiseks vali peamenüüs meeldiv mäng.
                        
                        Autorid: Michael Kevin Karlson, Martin Koitjärv, Sullo Saan
                        
                        """
        );
        info_tekstina.setTextAlignment(TextAlignment.CENTER);
        info_tekstina.setWrapText(true);

        Button tagasi = new Button("Tagasi");
        juur.getChildren().addAll(info_tekstina, tagasi);

        //nupp viib tagasi menüüsse
        tagasi.setOnMousePressed(event -> {
            Menüü menüü = new Menüü(primaryStage,mängija);
            primaryStage.getScene().setRoot(menüü.getJuur());
        });

        //kui akna suurust muudetakse, siis objektide suurust muudetakse vastavalt
        juur.widthProperty().addListener(observable -> uuenda(juur, tagasi, info_tekstina));
        juur.heightProperty().addListener(observable -> uuenda(juur, tagasi, info_tekstina));
    }

    private void uuenda(VBox juur, Button tagasi, Label info_tekstina) {
        double c = (juur.getWidth() + juur.getHeight()) / 2;
        tagasi.setStyle("-fx-font-size: " + c / 20 + "px;");
        info_tekstina.setFont(Font.font(c/30));
    }
}
