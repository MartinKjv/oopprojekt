package com.example.graafikaliides;

import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.util.LinkedList;
import java.util.List;

public class Saavutused {
    private BorderPane juur;

    public BorderPane getJuur() {
        return juur;
    }

    public Saavutused(Stage primaryStage, Mängija mängija) {
        juur = new BorderPane();
        primaryStage.setTitle("Saavutused");

        VBox vbox = new VBox();
        juur.prefHeightProperty().bind(primaryStage.getScene().heightProperty());
        juur.prefWidthProperty().bind(primaryStage.getScene().widthProperty());
        juur.setCenter(vbox);
        Button tagasi = new Button("Tagasi");
        tagasi.setAlignment(Pos.BOTTOM_LEFT);
        juur.setBottom(tagasi);
        vbox.setAlignment(Pos.TOP_LEFT);

        List<String> saavutused = mängija.getSaavutused();
        List<Text> saavutusedText = new LinkedList<>();
        saavutusedText.add(new Text("Oled mänginud "+mängija.getMängude_arv()+" mängu!"));

        if (saavutused.size()==0){
            saavutusedText.add(new Text("Sul pole ühtegi saavutust!"));
        }
        for (String saavutus:saavutused) {
            saavutusedText.add(new Text(saavutus));
        }
        for (Text saavutus:saavutusedText) {
            vbox.getChildren().add(saavutus);
        }

        tagasi.setOnMousePressed(event -> {
            Menüü menüü = new Menüü(primaryStage, mängija);
            primaryStage.getScene().setRoot(menüü.getJuur());
        });

        uuenda(juur, saavutusedText, tagasi);
        //kui akna suurust muudetakse, siis objektide suurust muudetakse vastavalt
        juur.widthProperty().addListener(observable -> uuenda(juur, saavutusedText, tagasi));
        juur.heightProperty().addListener(observable -> uuenda(juur, saavutusedText,tagasi));
    }

    private void uuenda(BorderPane juur, List<Text> saavutused, Button tagasi) {
        double c = (juur.getWidth() + juur.getHeight()) / 2;
        for (Text saavutus : saavutused) {
            saavutus.setFont(Font.font(c / 23));
        }
        tagasi.setStyle("-fx-text-fill: #ffffff;-fx-background-color: #000000; -fx-font-size: " + c / 30 + "px;");
    }
}
