package com.example.graafikaliides;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Wordle_Legacy extends Mäng_Legacy {

    @Override
    void lisaSaavutus(Mängija mängija, int k) {
        mängija.lisaSaavutused(mängija.getNimi()+" arvas ära sõna oma "+k+". pakkumisel.");
    }

    public void wordle_koopia(Mängija mängija) {

        List<String> sõnad = new ArrayList<>();

        String faili_nimi = "out_5.txt"; //faili nimi millest loeb sõnu

        File myObj = new File(faili_nimi);
        Scanner myReader;
        try {
            myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                sõnad.add(myReader.nextLine());
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        //leia suvaline sõna
        String sõne = sõnad.get((int) (Math.random() * sõnad.size())).toLowerCase();
        //String sõne = "AAEESS".toLowerCase();
        String sisesta;
        Scanner scan = new Scanner(System.in);

        System.out.println("Sõna on " + sõne.length() + " tähe pikkune");
        System.out.println("Lõpetamiseks arva sõna ära või kirjuta \"jeebus\"");

        String[] sõne_tükid;
        String[] sisesta_tükid;
        int arvamisteArv = 1;

        while (true) {

            System.out.print("Sisesta sõna: ");
            sisesta = scan.nextLine().toLowerCase();

            if (sõne.equals(sisesta)) {
                System.out.println("Tubli töö!");
                break;
            } else if (sisesta.equals("jeebus")) {
                break;
            } else if (sõne.length() != sisesta.length()) {
                System.out.println("Palun sisesta sõna mis on " + sõne.length() + " pikkune!");
                arvamisteArv +=1;

            } else if (!sõnad.contains(sisesta)) {
                System.out.println("Sellist sõna pole nimekirjas");
                arvamisteArv +=1;
            } else {
                arvamisteArv +=1;

                List<String> sisaldab = new ArrayList<>();

                sõne_tükid = sõne.split("");
                sisesta_tükid = sisesta.split("");

                for (String s : sõne_tükid) {
                    if (sisesta.contains(s)) {
                        if (!sisaldab.contains(s)) {
                            sisaldab.add(s);
                        }
                    }
                }

                String väljund = "";
                for (int i = 0; i < sõne.length(); i++) {
                    if (sõne_tükid[i].equals(sisesta_tükid[i])) {
                        väljund += sõne_tükid[i];
                    } else {
                        väljund += "_";
                    }
                }

                System.out.println(väljund);

                System.out.println("Lisaks sisaldab õige sõna tähti: " + sisaldab);
            }
        }
        lisaSaavutus(mängija, arvamisteArv);
        lisamäng(mängija);
        System.out.println("Wordle lõppeb...");
    }

}
