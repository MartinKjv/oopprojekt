package com.example.graafikaliides;

import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

public class ArvudFX extends Arvamisemäng {

    public ArvudFX(Stage primaryStage, Mängija mängija) {
        super(primaryStage, mängija);
    }

    @Override
    protected String saavutus(Mängija mängija, AtomicReference<Integer> arvamisteArv) {
        return mängija.getNimi() + " arvas ära arvu oma " + arvamisteArv + ". arvamisel!";
    }

    @Override
    protected void mängi(List<Text> arvamised, AtomicReference<Integer> arvamisteArv, TextField arvamiseKoht, Label juhis, AtomicBoolean onArvatud, VBox vbox, Button annaAlla, Text arvatudVarem, ImageView imageView) {
        juhis.setText("Ma mõtlen ühe arvu peale 1-st 1000-ni, arva see ära!");
        arvatudVarem.setText("Arvamised");
        int arv = (int) (Math.random() * 1000 + 1);     //genereeritakse arv, mida arvata
        Image image = null;

        try(FileInputStream fis = new FileInputStream("Arvamispildid/1.png")){
            image = new Image(fis);
        } catch (IOException e){
            System.out.println("Ei saanud taustapilti uuendada");
        }
        imageView.setImage(image);
        imageView.fitWidthProperty().bind(juur.widthProperty());
        imageView.fitHeightProperty().bind(juur.heightProperty());

        arvamiseKoht.setOnKeyReleased(event -> {
            //Kui vajutatakse Enterit ja mäng veel käib, siis kontrollitakse arvu
            if (event.getCode() == KeyCode.ENTER && !(onArvatud.get())) {
                String tekst = arvamiseKoht.getText();
                int kasutajaArvas;
                try {
                    kasutajaArvas = Integer.parseInt(tekst);
                    //Kui kasutaja arvas arvu, mis jääb vahemikust välja, palutakse sisestada uus arv
                    if (kasutajaArvas < 1 || kasutajaArvas > 1000){
                        throw new NumberFormatException();
                    }
                    arvamisteArv.getAndSet(arvamisteArv.get() + 1);
                    int suurem_väiksem;
                    if (kasutajaArvas != arv) {
                        if (kasutajaArvas < arv) {
                            juhis.setText("Minu arv on suurem!");
                            suurem_väiksem = 0;
                        } else {
                            juhis.setText("Minu arv on väiksem!");
                            suurem_väiksem = 1;
                        }
                        uuendaArvamisi(vbox, arvamised, tekst, juur, suurem_väiksem);
                        arvamiseKoht.clear();
                        uuendaPilt(imageView, arvamisteArv.get());

                    } else {
                        juhis.setText("Tubli töö! Arvasid ära!");
                        onArvatud.set(true);
                        annaAlla.setText("Tagasi");
                        arvamiseKoht.setText(tekst);
                        arvamiseKoht.setDisable(true);
                    }
                } catch (NumberFormatException e) {
                    juhis.setText("Sisesta täisarv vahemikus 1-st 1000-ni");
                }
            }
        });
    }

    private void uuendaPilt(ImageView imageView, int arvamisteArv) {
        //iga kahe arvamise järel taustapilt vahetatakse
        int arv = arvamisteArv/2;
        if (arv > 9)
            arv = 9;

        try(FileInputStream fis = new FileInputStream("ArvamisPildid/"+arv+".png")){
            Image image = new Image(fis);
            imageView.setImage(image);
        } catch (IOException e){
            System.out.println("Ei saanud taustapilti uuendada");
        }
    }

    protected void uuendaArvamisi(VBox vbox, List<Text> arvamised, String tekst, BorderPane juur, int suurem_väiksem) {
        boolean uus = true;
        for (Text info : arvamised) {
            if (tekst.equals(info.getText()))
                uus = false;
        }
        if (uus) {
            Text ajutine = new Text(tekst);
            vbox.getChildren().add(ajutine);
            arvamised.add(ajutine);

            if (suurem_väiksem == 0){
                ajutine.setFill(Color.BLUE);
            } else {
                ajutine.setFill(Color.RED);
            }
            double c = (juur.getWidth() + juur.getHeight()) / 2;
            for (Text text : arvamised) {
                text.setFont(Font.font(c / 20));
            }
        }
    }

    @Override
    protected void seaTiitel(Stage primaryStage) {
        primaryStage.setTitle("ArvudFX");
    }
}