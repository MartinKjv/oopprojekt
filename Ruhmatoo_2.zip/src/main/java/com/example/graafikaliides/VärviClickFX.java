package com.example.graafikaliides;

import javafx.animation.*;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

public class VärviClickFX {
    private BorderPane juur;
    private static AtomicInteger arvamisteArv = new AtomicInteger();

    public BorderPane getJuur() {
        return juur;
    }

    public VärviClickFX(Stage primaryStage, Mängija mängija) {
        juur = new BorderPane();
        juur.setStyle("-fx-font-size:30");
        primaryStage.setTitle("Värvi Klikkimine");
        Label juhis = new Label("Vajuta selle värvi peale, mis värvi on Tekst");
        juhis.setWrapText(true);
        Label juhis2 = new Label("Alustamiseks vajuta Alusta!");
        juhis2.setWrapText(true);
        VBox vbox = new VBox(juhis, juhis2);
        vbox.setAlignment(Pos.CENTER);
        juur.setTop(vbox);

        Button annaAlla = new Button("Anna alla");
        annaAlla.setAlignment(Pos.BOTTOM_LEFT);
        juur.setBottom(annaAlla);
        uuenda(juur, null, null, primaryStage);

        Button alusta = new Button("Alusta!");
        juur.setCenter(alusta);

        alusta.setOnMousePressed(event -> countDown(juur, primaryStage));

        annaAlla.setOnMousePressed(event -> {
            mängija.lisaMängude_arv();
            lisaSaavutus(mängija,arvamisteArv.get());
            Menüü menüü = new Menüü(primaryStage, mängija);
            primaryStage.getScene().setRoot(menüü.getJuur());
        });
    }

    private static void alusta(BorderPane juur, Stage primaryStage) {
        GridPane gridPane = new GridPane();
        Button button1 = new Button("BLUE");
        button1.setStyle("-fx-background-color: #0072CE;");
        Button button2 = new Button("BLACK");
        button2.setStyle("-fx-background-color: #000000;");
        button2.setTextFill(Color.WHITE);
        Button button3 = new Button("RED");
        button3.setStyle("-fx-background-color: #FF0000;");
        Button button4 = new Button("YELLOW");
        button4.setStyle("-fx-background-color: #FFFF00;");
        Button button5 = new Button("GREEN");
        button5.setStyle("-fx-background-color: #00FF00;");
        Button button6 = new Button("PINK");
        button6.setStyle("-fx-background-color: #FF00FF;"); //fuchsia
        List<Button> nupud = new LinkedList<>();
        nupud.add(button1);
        nupud.add(button2);
        nupud.add(button3);
        nupud.add(button4);
        nupud.add(button5);
        nupud.add(button6);
        gridPane.add(button1, 0, 0, 1, 1);
        gridPane.add(button2, 1, 0, 1, 1);
        gridPane.add(button3, 2, 0, 1, 1);
        gridPane.add(button4, 0, 1, 1, 1);
        gridPane.add(button5, 1, 1, 1, 1);
        gridPane.add(button6, 2, 1, 1, 1);
        gridPane.setAlignment(Pos.BOTTOM_CENTER);
        juur.setCenter(gridPane);
        BorderPane.setMargin(gridPane, new Insets(0, 0, primaryStage.getHeight() / 5, 0));

        ProgressBar progressBar = new ProgressBar();
        progressBar.prefWidthProperty().bind(primaryStage.widthProperty());
        Timeline timeline = new Timeline(
                new KeyFrame(Duration.ZERO, new KeyValue(progressBar.progressProperty(), 0)),
                new KeyFrame(Duration.seconds(999), e -> {  // aeg
                    failed(juur);
                }, new KeyValue(progressBar.progressProperty(), 1))
        );
        timeline.setCycleCount(Animation.INDEFINITE);
        timeline.play();

        Label label = new Label();
        label.setAlignment(Pos.CENTER);
        VBox vbox = new VBox(progressBar, label);
        vbox.setAlignment(Pos.CENTER);
        juur.setTop(vbox);
        vbox.prefWidthProperty().bind(primaryStage.widthProperty());

        label.setFont(Font.font("Verdana", FontWeight.BOLD, 60));

        uuenda(juur, label, nupud, primaryStage);
        primaryStage.widthProperty().addListener(observable -> uuenda(juur, label, nupud, primaryStage));
        primaryStage.heightProperty().addListener(observable -> uuenda(juur, label, nupud, primaryStage));

        AtomicReference<String> color = new AtomicReference<>(uusVärv(label));

        for (Button button : nupud) {
            button.setOnMousePressed(event -> {
                if (color.get().equalsIgnoreCase(button.getText())) {
                    timeline.jumpTo(Duration.millis(0));
                    color.set(uusVärv(label));
                } else failed(juur);
                arvamisteArv.getAndIncrement();
            });
        }
    }

    private static String uusVärv(Label label) {
        String color = getColor();
        String color2 = getColor();
        if (!color.equals(color2)) {
            label.setText(color2);
            label.setTextFill(GetColorColor(color));
            return color;
        }
        return uusVärv(label);
    }

    private static void failed(BorderPane juur) {
        juur.setTop(null);
        Text text = new Text("HA HA HA");
        text.setFont(Font.font("Verdana", FontWeight.BOLD, 40));
        juur.setCenter(text);
    }

    private static Paint GetColorColor(String color) {
        switch (color.toUpperCase()) {
            case "BLACK" -> {
                return Color.BLACK;
            }
            case "BLUE" -> {
                return Color.rgb(0, 114, 206);
            }
            case "RED" -> {
                return Color.RED;
            }
            case "YELLOW" -> {
                return Color.YELLOW;
            }
            case "PINK" -> {
                return Color.HOTPINK;
            }
            case "GREEN" -> {
                return Color.GREEN;
            }
            default -> throw new RuntimeException("VärviVärvi saamine läks nihu");
        }
    }

    private static String getColor() {
        int random = 1 + (int) (Math.random() * 6);
        switch (random) {
            case 1 -> {
                return "Black";
            }
            case 2 -> {
                return "Blue";
            }
            case 3 -> {
                return "Red";
            }
            case 4 -> {
                return "Yellow";
            }
            case 5 -> {
                return "Pink";
            }
            case 6 -> {
                return "Green";
            }
            default -> throw new RuntimeException("Värvi saamine läks nihu");
        }
    }

    private static void uuenda(BorderPane juur, Label label, List<Button> nupud, Stage primaryStage) {
        double c = (primaryStage.getWidth() + primaryStage.getHeight()) / 2;
        if (label != null)
            label.setFont(Font.font(c / 8));
        if (juur.getBottom() != null)
            juur.getBottom().setStyle("-fx-text-fill: #ffffff;-fx-background-color: #000000; -fx-font-size: " + c / 30 + "px;");
        if (nupud != null) {
            for (Button nupp : nupud) {
                //nupp.setStyle("-fx-font-size: " + c / 20 + "px;");
                nupp.setFont(Font.font("Verdana", FontWeight.BOLD, c / 20));
                nupp.setMinSize(primaryStage.getWidth() / 3, primaryStage.getHeight() / 20);
            }
        }
    }

    private static void countDown(BorderPane juur, Stage primaryStage) {
        juur.setTop(null);
        juur.setCenter(null);
        juur.setRight(null);
        juur.setLeft(null);

        Label label = new Label("3");
        juur.setCenter(label);
        label.setFont(Font.font(60));

        countDownRek(juur, label, primaryStage);
    }

    private static void countDownRek(BorderPane juur, Label label, Stage primaryStage) {
        FadeTransition trans = new FadeTransition(Duration.seconds(1.5), label);
        trans.setFromValue(1);
        trans.setToValue(.20);
        trans.setCycleCount(1);
        trans.play();
        trans.setOnFinished(event -> {
            label.setText(String.valueOf(Integer.parseInt(label.getText()) - 1));
            if (label.getText().equals("0"))
                alusta(juur, primaryStage);
            trans.setRate(trans.getRate() * -1);
            trans.playFromStart();
        });
    }

    private static void lisaSaavutus(Mängija mängija, int arv){
        mängija.lisaSaavutused(mängija.getNimi()+" arvas õigesti "+arv+" värvi!");
    }
}