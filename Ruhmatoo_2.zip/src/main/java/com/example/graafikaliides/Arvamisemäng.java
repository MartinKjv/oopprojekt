package com.example.graafikaliides;

import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

public abstract class Arvamisemäng {
    protected Pane juurPeal;
    protected BorderPane juur;

    public Pane getJuur() {
        return juurPeal;
    }

    public Arvamisemäng(Stage primaryStage, Mängija mängija){
        juurPeal = new Pane();
        juur = new BorderPane();
        seaTiitel(primaryStage);

        ImageView imageview = new ImageView();
        juurPeal.getChildren().add(imageview);
        juurPeal.getChildren().add(juur);
        juur.setStyle("-fx-font-size: 20pt;;");

        juur.prefHeightProperty().bind(primaryStage.getScene().heightProperty());
        juur.prefWidthProperty().bind(primaryStage.getScene().widthProperty());

        //muutujad
        List<Text> arvamised = new LinkedList<>();
        AtomicBoolean onArvatud = new AtomicBoolean(false);
        AtomicReference<Integer> arvamisteArv = new AtomicReference<>(0);

        //tekstiväljad ja nupud
        Label juhis = new Label("Mall");
        juhis.setFont(new Font("Verdana", 20));
        juhis.setWrapText(true);
        TextField arvamiseKoht = new TextField();
        arvamiseKoht.setOpacity(0.4);
        arvamiseKoht.setAlignment(Pos.CENTER_LEFT);
        Button annaAlla = new Button("Anna alla");

        HBox hbox = new HBox();
        hbox.setAlignment(Pos.CENTER_LEFT);
        hbox.getChildren().add(arvamiseKoht);
        VBox vbox = new VBox();
        ScrollPane sc = new ScrollPane(vbox);
        sc.hbarPolicyProperty().setValue(ScrollPane.ScrollBarPolicy.NEVER);
        sc.getStyleClass().clear(); //eemaldab halli ruudu ümbert ära

        juur.setTop(juhis);
        juur.setCenter(hbox);
        juur.setBottom(annaAlla);
        juur.setRight(sc);

        Text arvatudVarem = new Text("Mall-arvatud");
        vbox.getChildren().add(arvatudVarem);

        arvamised.add(arvatudVarem);
        annaAlla.setAlignment(Pos.BOTTOM_LEFT);

        //Anna alla nupp salvestab äraarvamise või allaandmise ja viib tagasi menüüsse
        annaAlla.setOnMousePressed(event -> {
            if (onArvatud.get()) {
                mängija.lisaSaavutused(saavutus(mängija, arvamisteArv));
            }
            mängija.lisaMängude_arv();

            Menüü menüü = new Menüü(primaryStage, mängija);
            primaryStage.getScene().setRoot(menüü.getJuur());
        });

        //kui akna suurust muudetakse, siis objektide suurust muudetakse vastavalt
        juur.widthProperty().addListener(observable -> uuenda(juur, juhis, annaAlla, arvamiseKoht, arvamised));
        juur.heightProperty().addListener(observable -> uuenda(juur, juhis, annaAlla, arvamiseKoht, arvamised));

        mängi(arvamised, arvamisteArv, arvamiseKoht, juhis, onArvatud, vbox, annaAlla, arvatudVarem,imageview);
    }

    protected abstract void seaTiitel(Stage primaryStage);

    protected abstract String saavutus(Mängija mängija, AtomicReference<Integer> arvamisteArv);

    protected abstract void mängi(List<Text> arvamised, AtomicReference<Integer> arvamisteArv, TextField arvamiseKoht, Label juhis, AtomicBoolean onArvatud, VBox vbox, Button annaAlla, Text arvatudVarem, ImageView imageview);

    protected void uuenda(BorderPane juur, Label juhis, Button anna_alla, TextField arvamise_koht, List<Text> arvamised) {
        double c = (juur.getWidth() + juur.getHeight()) / 2;
        juhis.setFont(Font.font(c / 20));
        //anna_alla.setFont(Font.font(h/30)); //põhjustab css errori
        anna_alla.setStyle("-fx-text-fill: #ffffff;-fx-background-color: #000000; -fx-font-size: " + c / 30 + "px;");
        arvamise_koht.setFont(Font.font(c / 15));
        arvamise_koht.setMaxWidth(c / 2);

        for (Text tekst : arvamised) {
            tekst.setFont(Font.font(c / 20));
        }
    }
}
