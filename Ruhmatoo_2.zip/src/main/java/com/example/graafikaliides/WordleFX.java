package com.example.graafikaliides;

import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

public class WordleFX extends Arvamisemäng{

    private List<String> loeSõnadeNimekiri(String faili_nimi) throws IOException {
        List<String> sõnad = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new InputStreamReader(
                new FileInputStream(faili_nimi), StandardCharsets.UTF_8))) {
            String rida = br.readLine();

            while(rida != null){
                sõnad.add(rida.toLowerCase());
                rida = br.readLine();
            }
        }
        return sõnad;
    }

    public WordleFX(Stage primaryStage, Mängija mängija) {
        super(primaryStage, mängija);
    }

    @Override
    protected String saavutus(Mängija mängija, AtomicReference<Integer> arvamisteArv) {
        return mängija.getNimi()+" arvas sõna ära oma "+arvamisteArv.get()+". katsel!";
    }

    @Override
    protected void seaTiitel(Stage primaryStage) {
        primaryStage.setTitle("WordleFX");
    }

    @Override
    protected void mängi(List<Text> arvamised, AtomicReference<Integer> arvamisteArv, TextField arvamiseKoht, Label juhis, AtomicBoolean onArvatud, VBox vbox, Button annaAlla, Text arvatudVarem, ImageView imageView){
        juhis.setText("Ma mõtlen ühe 5 tähelise sõna peale, arva see ära!");
        arvatudVarem.setText("Arvamised");

        //tagab, et ei kirjutata rohkem kui 5 tähte
        arvamiseKoht.setTextFormatter(new TextFormatter<>(c -> c.getControlNewText().matches(".{0,5}") ? c : null));

        List<String> sõnadeNimekiri = new ArrayList<>();
        String arvatavSõna = "";

        try {
            //valitakse juhuslikult sõna, mida arvata
            sõnadeNimekiri = loeSõnadeNimekiri("out_5.txt");
            arvatavSõna = sõnadeNimekiri.get((int) (Math.random()*sõnadeNimekiri.size()));
        } catch (IOException e) {
            //kui faili lugemisel tekib viga, siis näidatakse ainult veateadet ja tagasi-nuppu
            juur.getChildren().retainAll(juhis, annaAlla);
            annaAlla.setText("Tagasi");
            juhis.setText("Sõnade lugemine nimekirjast ei õnnestunud. Tekkis järgmine viga:\n"+e.getMessage()+"\n ");
            juhis.setTextFill(Color.RED);
        }
        assert sõnadeNimekiri.size()!=0;

        String[] arvatavaTähed = arvatavSõna.split("");

        //lambda-avaldis nõuab final muutujaid
        final String finalArvatavSõna = arvatavSõna;
        final List<String> finalSõnadeNimekiri = sõnadeNimekiri;

        arvamiseKoht.setOnKeyReleased(event -> {
            //Kui vajutatakse Enterit ja mäng veel käib, siis kontrollitakse sõna
            if (event.getCode() == KeyCode.ENTER && !(onArvatud.get())) {
                String tekst = arvamiseKoht.getText().toLowerCase();

                if (tekst.length() != 5){
                    juhis.setText("Sisesta 5-täheline sõna");
                } else if (tekst.equals(finalArvatavSõna)){
                    juhis.setText("Tubli töö! Arvasid ära!");
                    onArvatud.set(true);
                    annaAlla.setText("Tagasi");
                    arvamiseKoht.setText(finalArvatavSõna);
                    arvamiseKoht.setDisable(true);
                } else if(finalSõnadeNimekiri.contains(tekst)){
                    juhis.setText(
                            "Suured tähed on õigete kohtade peal, " +
                            "väiksed tähed on sõnas olemas, aga teises kohas. " +
                            "Alakriipsud on valed tähed. " +
                            "Proovi uuesti!");
                    arvamisteArv.set(arvamisteArv.get()+1);

                    String[] sisestatudTähed = tekst.split("");

                    StringBuilder väljund = new StringBuilder();

                    for (int i = 0; i < finalArvatavSõna.length(); i++) {
                        if (arvatavaTähed[i].equals(sisestatudTähed[i])) {
                            väljund.append(arvatavaTähed[i].toUpperCase());
                        } else if(finalArvatavSõna.contains(sisestatudTähed[i])) {
                            väljund.append(sisestatudTähed[i]);
                        } else {
                            väljund.append("_");
                        }
                    }
                    arvamiseKoht.clear();
                    uuendaArvamisi(vbox, arvamised, String.valueOf(väljund), juur);
                } else {
                    juhis.setText("Sellist sõna ma ei tunne");
                    //välja kommenteeritud, sest päris Wordle ei võta ühte arvamiskorda ära, kui pakutud sõna pole olemas
                    //arvamisteArv.set(arvamisteArv.get() + 1);
                }
            }
        });
    }

    protected void uuendaArvamisi(VBox vbox, List<Text> arvamised, String tekst, BorderPane juur) {
        boolean uus = true;
        for (Text info : arvamised) {
            if (tekst.equals(info.getText()))
                uus = false;
        }
        if (uus) {
            Text ajutine = new Text(tekst);
            vbox.getChildren().add(ajutine);
            arvamised.add(ajutine);

            double c = (juur.getWidth() + juur.getHeight()) / 2;
            for (Text text:arvamised) {
                text.setFont(Font.font(c / 20));
            }
        }
    }
}
