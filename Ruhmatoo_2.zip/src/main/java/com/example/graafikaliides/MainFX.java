package com.example.graafikaliides;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class MainFX extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        Group juur = new Group();

        //Käivitamisel avaneb kõigepealt kasutajanime valik
        TextField tf = new TextField();
        BorderPane bp = new BorderPane();
        HBox hbox = new HBox();
        juur.getChildren().add(bp);
        Label label = new Label("Sisesta oma nimi");
        label.setFont(Font.font(30));
        bp.setTop(label);

        //easter egg, mis käivitab rühmatöö 1. versiooni, s.t. konsoolis
        Button legacy = new Button();
        legacy.setMinSize(20,20);
        legacy.setBackground(null);
        legacy.setAlignment(Pos.BOTTOM_LEFT);
        bp.setBottom(legacy);

        bp.setCenter(hbox);
        hbox.getChildren().add(tf);
        hbox.setAlignment(Pos.CENTER);
        tf.setAlignment(Pos.CENTER_LEFT);
        tf.setFont(Font.font("Verdena", 30));

        Scene mainFX = new Scene(juur, 500, 500);
        bp.setPrefSize(500,500);
        primaryStage.setScene(mainFX);
        primaryStage.show();

        tf.setOnKeyReleased(event -> {
            //Kui vajutatakse Enterit ja tekstiväli pole tühi, siis minnakse peamenüüsse
            if (event.getCode() == KeyCode.ENTER && !tf.getText().equals("")) {
                String nimi = tf.getText();
                Mängija mängija = new Mängija(nimi);
                Menüü menüü = new Menüü(primaryStage, mängija);
                primaryStage.getScene().setRoot(menüü.getJuur());
            }
        });

        legacy.setOnMousePressed(event -> {
            Main_Legacy.main(null);
        });
    }
}
/*
Peaklassis luuakse vaid need asjad, mida on kõigis stseenides vaja.
Menüü on eraldi klass, et sellega saaks ümber käia samamoodi, nagu teiste stseenidega.
See oli ainus mõistlik viis, kuidas saab teistest stseenidest ka menüüsse tagasi tulla.
*/