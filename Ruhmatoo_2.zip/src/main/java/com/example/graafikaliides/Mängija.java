package com.example.graafikaliides;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Mängija {
    private String nimi;
    private List<String> saavutused;
    private int mängude_arv;
    LocalDateTime algusAeg;

    public Mängija(String nimi) {
        this.nimi = nimi;
        this.saavutused = new ArrayList<>();
        this.mängude_arv = 0;
        this.algusAeg = LocalDateTime.now();
    }

    public void mänguaeg() {
        Duration duration = Duration.between(algusAeg, LocalDateTime.now());
        System.out.println(nimi + " on mänginud: " + duration.getSeconds() + " sekundit!");
    }

    public String getNimi() {
        return nimi;
    }

    public List<String> getSaavutused() {
        return saavutused;
    }

    public int getMängude_arv() {
        return mängude_arv;
    }

    public void lisaSaavutused(String saavutus) {
        this.saavutused.add(saavutus);
    }

    public void setNimi(String nimi) {
        this.nimi = nimi;
    }

    public void lisaMängude_arv() {
        this.mängude_arv += 1;
    }

    public void saadasaavutused() {
        System.out.println(nimi + " on saavutanud järgmised saavutused:");
        if (saavutused.size() == 0) {
            System.out.println("Sa pole midagi saavutanud");
        } else {
            for (String saavutus : saavutused) {
                System.out.println(saavutus);
            }
        }
    }
}
