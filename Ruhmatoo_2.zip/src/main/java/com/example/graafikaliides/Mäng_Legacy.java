package com.example.graafikaliides;

public abstract class Mäng_Legacy {

    public void lisamäng(Mängija mängija){
        mängija.lisaMängude_arv();
    }

    abstract void lisaSaavutus(Mängija mängija, int k);

}
