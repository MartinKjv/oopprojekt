package com.example.graafikaliides;

import java.util.Scanner;

public class Main_Legacy {
    public static void main(String[] args) {

        Wordle_Legacy wordle = new Wordle_Legacy();
        Arvud_Legacy arvud = new Arvud_Legacy();

        boolean jah = true;
        Scanner scan = new Scanner(System.in);
        String sisesta;
        System.out.print("Alustamiseks palun sisesta oma nimi: ");
        sisesta = scan.nextLine();
        Mängija mängija = new Mängija(sisesta);
        System.out.println("Mängud algavad!");
        while (jah) {
            System.out.println("Lõpetamiseks kirjuta \"Cowabunga\"");
            System.out.println("Mänguaja teadasaamiseks kirjuta \"Aeg\"");
            System.out.println("Oma saavutuste teadasaamiseks kirjuta \"Saavutused\"");
            System.out.println("Oma nime muutmiseks kirjuta \"nimeta\"");
            System.out.println("Et teadasaada mitu mängu oled mänginud kirjuta \"Kordus\"");
            System.out.print("Vali mäng: \"Wordle\" või \"Arvu arvamine\"");
            System.out.println();

            sisesta = scan.nextLine().toLowerCase();

            switch (sisesta) {
                case "cowabunga" -> {
                    System.out.println("lõpetan...");
                    jah = false;
                }
                case "wordle" -> {
                    System.out.println("Wordle stardib...");
                    wordle.wordle_koopia(mängija);
                }
                case "arvu arvamine" -> {
                    System.out.println("Arvu arvamine algab...");
                    arvud.arvuarvamine(mängija);
                }
                case "kordus" -> System.out.println("Oled mänginud: "+mängija.getMängude_arv()+" mängu.");
                case "aeg" -> mängija.mänguaeg();
                case "saavutused" -> mängija.saadasaavutused();
                case "nimeta" ->{
                    System.out.print("Sisesta uus nimi: ");
                    mängija.setNimi(scan.nextLine());
                }
            }
        }
        System.out.println("Mängud läbi!");
    }
}
