package com.example.graafikaliides;

import java.util.Scanner;

public class Arvud_Legacy extends Mäng_Legacy {

    @Override
    void lisaSaavutus(Mängija mängija, int k) {
        mängija.lisaSaavutused(mängija.getNimi()+" arvas ära sõna oma "+k+". pakkumisel.");
    }
    public void arvuarvamine(Mängija mängija) {
        System.out.println("Ma mõtlen ühest arvust mis on 0 ja 1000 vahel, arva ära mis arv see on!");
        System.out.println("Et anda alla kirjuta \"Austria\"");
        int arv = (int) (Math.random() * 1000);
        Scanner scan = new Scanner(System.in);
        String sisesta;
        int arvatud_arv;
        int arvamisteArv=1;

        while (true) {
            System.out.print("Arva arvu: ");
            sisesta = scan.nextLine().toLowerCase();
            if (sisesta.equals("austria")) {
                break;
            }
            try {
                arvatud_arv = Integer.parseInt(sisesta);
                if (arvatud_arv != arv) {
                    if (arvatud_arv < arv) {
                        System.out.println("Minu arv on suurem!");
                    } else {
                        System.out.println("Minu arv on väiksem");
                    }
                    arvamisteArv+=1;
                } else {
                    System.out.println("Arvasid ära!");
                    System.out.println("Tubli töö!");
                    break;
                }
            } catch (Exception e) {
                System.out.println("Ei saanud arvust aru, palun proovi uuesti");
                arvamisteArv+=1;
            }
        }
        lisaSaavutus(mängija, arvamisteArv);
        lisamäng(mängija);
        System.out.println("Arvu arvamismäng lõppeb...");
    }
}
