package com.example.graafikaliides;

import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class Menüü {
    private BorderPane juur;

    public BorderPane getJuur() {
        return juur;
    }

    public Menüü(Stage primaryStage, Mängija mängija) {
        juur = new BorderPane();
        primaryStage.setTitle("OOP Mängud");

        VBox vbox = new VBox();
        HBox hbox = new HBox();
        juur.setCenter(vbox);
        Label label = new Label("Tere "+mängija.getNimi()+"!");
        hbox.getChildren().add(label);
        hbox.setAlignment(Pos.CENTER);
        juur.setTop(hbox);
        vbox.setAlignment(Pos.CENTER);

        //nuppude loomine
        List<Button> nupud = new LinkedList<>();
        Button wordle = new Button("Wordle");
        Button arvuArvamine = new Button("Arvu arvamine");
        Button info = new Button("Info");
        Button saavutused = new Button("Saavutused");
        Button värviClick = new Button("Värvi klikkimine");
        vbox.getChildren().addAll(wordle, arvuArvamine, värviClick, saavutused, info);

        Button pluss = new Button("+");
        Button miinus = new Button("-");
        Region region = new Region();
        HBox hbox2 = new HBox(miinus, region, pluss);
        HBox.setHgrow(region, Priority.ALWAYS);
        pluss.setAlignment(Pos.BOTTOM_RIGHT);
        miinus.setAlignment(Pos.BOTTOM_LEFT);
        pluss.setMinSize(20,20);
        miinus.setMinSize(20,20);
        juur.setBottom(hbox2);
        AtomicInteger korrutaja = new AtomicInteger(100);

        nupud.add(wordle);
        nupud.add(arvuArvamine);
        nupud.add(info);
        nupud.add(saavutused);
        nupud.add(värviClick);
        nupud.add(miinus);
        nupud.add(pluss);

        //nupud viivad eraldi stseenidesse
        wordle.setOnMousePressed(event -> {
            WordleFX wordleFX = new WordleFX(primaryStage, mängija);
            primaryStage.getScene().setRoot(wordleFX.getJuur());
        });
        arvuArvamine.setOnMousePressed(event -> {
            ArvudFX arvudFX = new ArvudFX(primaryStage, mängija);
            primaryStage.getScene().setRoot(arvudFX.getJuur());
        });
        info.setOnMousePressed(event -> {
            Info info1 = new Info(primaryStage, mängija);
            primaryStage.getScene().setRoot(info1.getJuur());
        });
        saavutused.setOnMousePressed(event -> {
            Saavutused saavutused1 = new Saavutused(primaryStage, mängija);
            primaryStage.getScene().setRoot(saavutused1.getJuur());
        });
        värviClick.setOnMousePressed(event -> {
            VärviClickFX värviClickFX = new VärviClickFX(primaryStage, mängija);
            primaryStage.getScene().setRoot(värviClickFX.getJuur());
        });

        //nuppude suuruste muutmine
        miinus.setOnMousePressed(event -> {
            if (korrutaja.get() > 40)
                korrutaja.addAndGet(-5);
            uuenda(juur, label, nupud,korrutaja);
        });
        pluss.setOnMousePressed(event -> {
            if (korrutaja.get() < 150)
                korrutaja.addAndGet(5);
            uuenda(juur, label, nupud,korrutaja);
        });

        //kui akna suurust muudetakse, siis objektide suurust muudetakse vastavalt
        juur.widthProperty().addListener(observable -> uuenda(juur, label, nupud,korrutaja));
        juur.heightProperty().addListener(observable -> uuenda(juur, label, nupud, korrutaja));
    }

    private void uuenda(BorderPane juur, Label label, List<Button> nupud, AtomicInteger korrutaja) {
        double c = (juur.getWidth() + juur.getHeight()) / 2*((double)korrutaja.get()/100);
        label.setFont(Font.font(c / 20));
        for (Button nupp:nupud) {
            nupp.setStyle("-fx-font-size: " + c / 20 + "px;");
        }
    }
}
