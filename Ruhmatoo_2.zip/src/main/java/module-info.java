module com.example.graafikaliides {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;


    opens com.example.graafikaliides to javafx.fxml;
    exports com.example.graafikaliides;
}